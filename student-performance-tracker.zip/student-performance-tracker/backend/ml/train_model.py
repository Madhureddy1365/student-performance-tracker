"""
train_model.py
----------------
Student Performance Tracker - Model Training Script

What this script does:
1. Loads a student dataset from backend/data/student_data.csv.
   If the file does not exist, a realistic synthetic dataset is generated
   and saved to that path first.
2. Cleans the data (handles missing values, encodes any categorical columns).
3. Splits the data into train/test sets.
4. Trains three regression models:
      - Linear Regression
      - Decision Tree Regressor
      - Random Forest Regressor
5. Evaluates each model using MAE, MSE, RMSE and R^2.
6. Selects the best model (highest R^2 on the test set).
7. Saves the best model, the fitted scaler, the feature list and the
   comparison metrics to backend/ml/models/ so the Flask API can load them.

Run it from the backend/ directory:
    python ml/train_model.py
"""

import os
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # backend/
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")  # backend/ml/models
DATASET_PATH = os.path.join(DATA_DIR, "student_data.csv")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

FEATURE_COLUMNS = [
    "attendance_percentage",
    "study_hours",
    "previous_marks",
    "assignment_score",
    "internal_exam_score",
    "assignments_completed",
    "participation_score",
]
TARGET_COLUMN = "final_score"

RANDOM_STATE = 42


# ---------------------------------------------------------------------------
# Step 1: Generate a synthetic dataset (only if one does not already exist)
# ---------------------------------------------------------------------------
def generate_sample_dataset(n_students: int = 400) -> pd.DataFrame:
    """Creates a realistic, formula-driven + noisy dataset of students."""
    rng = np.random.default_rng(RANDOM_STATE)

    attendance_percentage = np.clip(rng.normal(78, 12, n_students), 40, 100)
    study_hours = np.clip(rng.normal(4.5, 2.0, n_students), 0, 10)
    previous_marks = np.clip(rng.normal(68, 15, n_students), 20, 100)
    assignment_score = np.clip(rng.normal(70, 14, n_students), 0, 100)
    internal_exam_score = np.clip(rng.normal(65, 15, n_students), 0, 100)
    assignments_completed = np.clip(rng.normal(15, 4, n_students), 0, 20).round()
    participation_score = np.clip(rng.normal(6.5, 2.0, n_students), 0, 10)
    # Optional categorical column kept to demonstrate categorical encoding in
    # the preprocessing step below. Not required by the app's Add Student form.
    extra_curricular = rng.choice(["Yes", "No"], size=n_students, p=[0.4, 0.6])

    # Weighted formula (each sub-component normalised to a 0-100 scale) plus noise
    final_score = (
        0.20 * attendance_percentage
        + 0.15 * (study_hours / 10 * 100)
        + 0.20 * previous_marks
        + 0.15 * assignment_score
        + 0.20 * internal_exam_score
        + 0.05 * (assignments_completed / 20 * 100)
        + 0.05 * (participation_score / 10 * 100)
    )
    # Small bonus for extracurricular involvement
    final_score += np.where(extra_curricular == "Yes", 1.5, 0)

    # Non-linear effects (threshold penalties + an interaction term) so that
    # tree-based ensembles like Random Forest have a genuine edge over a
    # plain linear model - mirrors real-world academic data where risk
    # factors compound rather than add up neatly.
    final_score -= np.where(attendance_percentage < 60, 12, 0)
    final_score -= np.where(internal_exam_score < 40, 8, 0)
    final_score += 0.04 * (study_hours * internal_exam_score) - 2.0
    final_score += rng.normal(0, 4.5, n_students)
    final_score = np.clip(final_score, 0, 100)

    df = pd.DataFrame(
        {
            "student_id": [f"STU{1000 + i}" for i in range(n_students)],
            "name": [f"Student {i + 1}" for i in range(n_students)],
            "attendance_percentage": attendance_percentage.round(1),
            "study_hours": study_hours.round(1),
            "previous_marks": previous_marks.round(1),
            "assignment_score": assignment_score.round(1),
            "internal_exam_score": internal_exam_score.round(1),
            "assignments_completed": assignments_completed.astype(int),
            "participation_score": participation_score.round(1),
            "extra_curricular": extra_curricular,
            "final_score": final_score.round(1),
        }
    )

    # Sprinkle a few missing values to exercise the preprocessing step
    for col in ["attendance_percentage", "study_hours", "assignment_score"]:
        mask = rng.random(n_students) < 0.02
        df.loc[mask, col] = np.nan

    return df


def load_or_create_dataset() -> pd.DataFrame:
    if os.path.exists(DATASET_PATH):
        print(f"Loading existing dataset from {DATASET_PATH}")
        return pd.read_csv(DATASET_PATH)

    print("No dataset found. Generating a synthetic sample dataset...")
    df = generate_sample_dataset()
    df.to_csv(DATASET_PATH, index=False)
    print(f"Sample dataset saved to {DATASET_PATH} ({len(df)} rows)")
    return df


# ---------------------------------------------------------------------------
# Step 2: Preprocessing
# ---------------------------------------------------------------------------
def preprocess(df: pd.DataFrame):
    df = df.copy()

    # --- Handle missing values ---
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    for col in numeric_cols:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].median())

    # --- Encode categorical columns where necessary ---
    categorical_cols = df.select_dtypes(include=["object", "string"]).columns.tolist()
    categorical_cols = [c for c in categorical_cols if c not in ("student_id", "name")]
    for col in categorical_cols:
        df[col] = df[col].fillna(df[col].mode()[0])
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])

    # Only keep the columns the Flask API's Add Student form actually collects,
    # plus the target. (extra_curricular, if present, is dropped so the model's
    # feature list matches exactly what the frontend sends.)
    feature_cols = [c for c in FEATURE_COLUMNS if c in df.columns]
    X = df[feature_cols]
    y = df[TARGET_COLUMN]
    return X, y, feature_cols


# ---------------------------------------------------------------------------
# Step 3-6: Train, evaluate, compare, select best model
# ---------------------------------------------------------------------------
def train_and_evaluate(X, y):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(random_state=RANDOM_STATE, max_depth=6),
        "Random Forest": RandomForestRegressor(
            n_estimators=200, random_state=RANDOM_STATE, max_depth=10
        ),
    }

    results = {}
    fitted_models = {}

    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_test_scaled)

        mae = mean_absolute_error(y_test, preds)
        mse = mean_squared_error(y_test, preds)
        rmse = float(np.sqrt(mse))
        r2 = r2_score(y_test, preds)

        results[name] = {
            "MAE": round(float(mae), 3),
            "MSE": round(float(mse), 3),
            "RMSE": round(rmse, 3),
            "R2": round(float(r2), 4),
        }
        fitted_models[name] = model
        print(f"{name:>20s} | MAE={mae:.3f}  MSE={mse:.3f}  RMSE={rmse:.3f}  R2={r2:.4f}")

    best_name = max(results, key=lambda k: results[k]["R2"])
    best_model = fitted_models[best_name]
    print(f"\nBest model: {best_name} (R2={results[best_name]['R2']})")

    return best_name, best_model, scaler, results


# ---------------------------------------------------------------------------
# Step 7: Save artifacts
# ---------------------------------------------------------------------------
def save_artifacts(best_name, best_model, scaler, feature_cols, results):
    joblib.dump(best_model, os.path.join(MODEL_DIR, "best_model.pkl"))
    joblib.dump(scaler, os.path.join(MODEL_DIR, "scaler.pkl"))

    metadata = {
        "best_model": best_name,
        "feature_columns": feature_cols,
        "metrics": results,
    }
    with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"\nSaved model artifacts to {MODEL_DIR}")


def main():
    df = load_or_create_dataset()
    X, y, feature_cols = preprocess(df)
    best_name, best_model, scaler, results = train_and_evaluate(X, y)
    save_artifacts(best_name, best_model, scaler, feature_cols, results)


if __name__ == "__main__":
    main()
