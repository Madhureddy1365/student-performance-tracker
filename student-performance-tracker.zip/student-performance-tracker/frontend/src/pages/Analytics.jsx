import React, { useEffect, useState } from "react";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  BarChart,
  Bar,
} from "recharts";
import Loader from "../components/Loader";
import { AnalyticsAPI, ModelAPI } from "../api/api";

const CATEGORY_COLORS = {
  Excellent: "#1f9d55",
  Good: "#2f80ed",
  Average: "#e0a02c",
  "Needs Improvement": "#d64545",
  Unclassified: "#94a3b8",
};

const METRIC_COLORS = {
  "Linear Regression": "#2f80ed",
  "Decision Tree": "#e0a02c",
  "Random Forest": "#1f9d55",
};

function ScatterCard({ title, data, xKey, yKey, xLabel, yLabel }) {
  return (
    <div className="card chart-card">
      <h3>{title}</h3>
      <ResponsiveContainer width="100%" height={280}>
        <ScatterChart margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e9f0" />
          <XAxis
            type="number"
            dataKey={xKey}
            name={xLabel}
            tick={{ fontSize: 12 }}
            label={{ value: xLabel, position: "insideBottom", offset: -5, fontSize: 12 }}
          />
          <YAxis
            type="number"
            dataKey={yKey}
            name={yLabel}
            tick={{ fontSize: 12 }}
            label={{ value: yLabel, angle: -90, position: "insideLeft", fontSize: 12 }}
          />
          <ZAxis range={[60, 60]} />
          <Tooltip cursor={{ strokeDasharray: "3 3" }} />
          <Scatter data={data} fill="#1e3a5f" fillOpacity={0.75} />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function Analytics() {
  const [points, setPoints] = useState([]);
  const [breakdown, setBreakdown] = useState({});
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    Promise.all([AnalyticsAPI.data(), ModelAPI.metrics().catch(() => null)])
      .then(([analyticsRes, metricsRes]) => {
        if (!mounted) return;
        setPoints(analyticsRes.points);
        setBreakdown(analyticsRes.category_breakdown);
        setMetrics(metricsRes);
      })
      .catch((err) => mounted && setError(err.message))
      .finally(() => mounted && setLoading(false));
    return () => {
      mounted = false;
    };
  }, []);

  if (loading) return <Loader label="Loading analytics..." />;
  if (error) {
    return (
      <div className="page">
        <div className="alert alert-error">{error}</div>
      </div>
    );
  }

  const pieData = Object.entries(breakdown).map(([name, value]) => ({ name, value }));

  const metricRows = metrics
    ? Object.entries(metrics.metrics).map(([model, m]) => ({ model, ...m }))
    : [];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Analytics</h1>
          <p className="page-subtitle">Relationships between academic factors and predicted performance</p>
        </div>
      </div>

      {points.length === 0 ? (
        <div className="empty-state">
          <h3>No data to analyze yet</h3>
          <p>Add students to unlock attendance, study-hours, and performance charts.</p>
        </div>
      ) : (
        <div className="chart-grid">
          <ScatterCard
            title="Attendance vs Predicted Marks"
            data={points}
            xKey="attendance_percentage"
            yKey="predicted_score"
            xLabel="Attendance (%)"
            yLabel="Predicted Score"
          />
          <ScatterCard
            title="Study Hours vs Predicted Marks"
            data={points}
            xKey="study_hours"
            yKey="predicted_score"
            xLabel="Study Hours"
            yLabel="Predicted Score"
          />
          <ScatterCard
            title="Assignment Score vs Predicted Marks"
            data={points}
            xKey="assignment_score"
            yKey="predicted_score"
            xLabel="Assignment Score"
            yLabel="Predicted Score"
          />

          <div className="card chart-card">
            <h3>Student Performance Distribution</h3>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={95}
                  label={(entry) => `${entry.name}: ${entry.value}`}
                >
                  {pieData.map((entry) => (
                    <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] || "#94a3b8"} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="card chart-card" style={{ marginTop: 24 }}>
        <h3>Model Performance Comparison</h3>
        {metrics ? (
          <>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={metricRows}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e9f0" />
                <XAxis dataKey="model" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="RMSE" radius={[6, 6, 0, 0]}>
                  {metricRows.map((row) => (
                    <Cell key={row.model} fill={METRIC_COLORS[row.model] || "#94a3b8"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Model</th>
                    <th>MAE</th>
                    <th>MSE</th>
                    <th>RMSE</th>
                    <th>R²</th>
                  </tr>
                </thead>
                <tbody>
                  {metricRows.map((row) => (
                    <tr key={row.model} className={row.model === metrics.best_model ? "row-highlight" : ""}>
                      <td>
                        {row.model}
                        {row.model === metrics.best_model && <span className="badge badge-good" style={{ marginLeft: 8 }}>Best</span>}
                      </td>
                      <td>{row.MAE}</td>
                      <td>{row.MSE}</td>
                      <td>{row.RMSE}</td>
                      <td>{row.R2}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <p className="page-subtitle">Model metrics unavailable — train the model by running ml/train_model.py.</p>
        )}
      </div>
    </div>
  );
}
