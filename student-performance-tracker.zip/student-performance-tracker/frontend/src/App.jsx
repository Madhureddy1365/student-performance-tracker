import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import { ToastProvider } from "./components/Toast";
import Dashboard from "./pages/Dashboard";
import AddStudent from "./pages/AddStudent";
import StudentRecords from "./pages/StudentRecords";
import StudentDetail from "./pages/StudentDetail";
import Analytics from "./pages/Analytics";

export default function App() {
  return (
    <ToastProvider>
      <BrowserRouter>
        <div className="app-shell">
          <Sidebar />
          <main className="app-content">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/add-student" element={<AddStudent />} />
              <Route path="/students" element={<StudentRecords />} />
              <Route path="/students/:id" element={<StudentDetail />} />
              <Route path="/students/:id/edit" element={<AddStudent />} />
              <Route path="/analytics" element={<Analytics />} />
            </Routes>
          </main>
        </div>
      </BrowserRouter>
    </ToastProvider>
  );
}
