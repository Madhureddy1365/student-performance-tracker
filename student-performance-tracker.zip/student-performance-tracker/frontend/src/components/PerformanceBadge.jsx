import React from "react";

const TONE_MAP = {
  Excellent: "excellent",
  Good: "good",
  Average: "average",
  "Needs Improvement": "poor",
};

export default function PerformanceBadge({ category }) {
  const tone = TONE_MAP[category] || "default";
  return <span className={`badge badge-${tone}`}>{category || "Unclassified"}</span>;
}
