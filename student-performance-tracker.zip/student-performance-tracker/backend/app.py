"""
app.py
------
Student Performance Tracker - Flask API

Endpoints:
    GET    /api/health                 -> liveness check
    GET    /api/students                -> list all students (supports ?search=&category=)
    POST   /api/students                -> create a student (auto-predicts + stores score)
    GET    /api/students/<id>           -> get one student
    PUT    /api/students/<id>           -> update a student (re-predicts)
    DELETE /api/students/<id>           -> delete a student
    POST   /api/predict                 -> predict without saving to DB
    GET    /api/dashboard/stats         -> aggregated dashboard statistics
    GET    /api/analytics/data          -> raw per-student data for charts
    GET    /api/model/metrics           -> model comparison metrics (MAE/MSE/RMSE/R2)

Run:
    python app.py
"""

import os
from flask import Flask, request, jsonify

import database as db
from ml import predict as ml

app = Flask(__name__)

REQUIRED_FIELDS = [
    "student_id",
    "name",
    "attendance_percentage",
    "study_hours",
    "previous_marks",
    "assignment_score",
    "internal_exam_score",
    "assignments_completed",
    "participation_score",
]

NUMERIC_FIELDS = {
    "attendance_percentage": (0, 100),
    "study_hours": (0, 24),
    "previous_marks": (0, 100),
    "assignment_score": (0, 100),
    "internal_exam_score": (0, 100),
    "assignments_completed": (0, 100),
    "participation_score": (0, 10),
}


# ---------------------------------------------------------------------------
# CORS (handled manually so we don't need the flask-cors package)
# ---------------------------------------------------------------------------
@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return response


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def cors_preflight(_any):
    return "", 204


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_student_payload(payload: dict):
    errors = []

    for field in REQUIRED_FIELDS:
        if field not in payload or payload[field] in (None, ""):
            errors.append(f"'{field}' is required.")

    if errors:
        return errors

    if not isinstance(payload["student_id"], str) or not payload["student_id"].strip():
        errors.append("'student_id' must be a non-empty string.")
    if not isinstance(payload["name"], str) or not payload["name"].strip():
        errors.append("'name' must be a non-empty string.")

    for field, (lo, hi) in NUMERIC_FIELDS.items():
        value = payload.get(field)
        try:
            value = float(value)
        except (TypeError, ValueError):
            errors.append(f"'{field}' must be a number.")
            continue
        if value < lo or value > hi:
            errors.append(f"'{field}' must be between {lo} and {hi}.")

    return errors


def extract_features(payload: dict) -> dict:
    return {
        "attendance_percentage": float(payload["attendance_percentage"]),
        "study_hours": float(payload["study_hours"]),
        "previous_marks": float(payload["previous_marks"]),
        "assignment_score": float(payload["assignment_score"]),
        "internal_exam_score": float(payload["internal_exam_score"]),
        "assignments_completed": float(payload["assignments_completed"]),
        "participation_score": float(payload["participation_score"]),
    }


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "student-performance-tracker-api"})


# ---------------------------------------------------------------------------
# Students CRUD
# ---------------------------------------------------------------------------
@app.route("/api/students", methods=["GET"])
def list_students():
    search = request.args.get("search", "").strip().lower()
    category = request.args.get("category", "").strip()

    students = db.get_all_students()

    if search:
        students = [
            s
            for s in students
            if search in s["name"].lower() or search in s["student_id"].lower()
        ]
    if category:
        students = [s for s in students if s.get("performance_category") == category]

    return jsonify({"students": students, "count": len(students)})


@app.route("/api/students", methods=["POST"])
def create_student():
    payload = request.get_json(silent=True) or {}
    errors = validate_student_payload(payload)
    if errors:
        return jsonify({"errors": errors}), 400

    if db.student_id_exists(payload["student_id"].strip()):
        return jsonify({"errors": [f"Student ID '{payload['student_id']}' already exists."]}), 409

    features = extract_features(payload)

    try:
        result = ml.predict_student(features)
    except ml.ModelNotTrainedError as e:
        return jsonify({"errors": [str(e)]}), 503

    record = {
        "student_id": payload["student_id"].strip(),
        "name": payload["name"].strip(),
        **features,
        "predicted_score": result["predicted_score"],
        "performance_category": result["performance_category"],
    }

    new_id = db.insert_student(record)
    student = db.get_student_by_id(new_id)

    return (
        jsonify(
            {
                "student": student,
                "recommendations": result["recommendations"],
                "model_used": result["model_used"],
            }
        ),
        201,
    )


@app.route("/api/students/<int:record_id>", methods=["GET"])
def get_student(record_id):
    student = db.get_student_by_id(record_id)
    if not student:
        return jsonify({"errors": ["Student not found."]}), 404

    features = extract_features(student)
    try:
        result = ml.predict_student(features)
        recommendations = result["recommendations"]
    except ml.ModelNotTrainedError:
        recommendations = []

    return jsonify({"student": student, "recommendations": recommendations})


@app.route("/api/students/<int:record_id>", methods=["PUT"])
def update_student(record_id):
    existing = db.get_student_by_id(record_id)
    if not existing:
        return jsonify({"errors": ["Student not found."]}), 404

    payload = request.get_json(silent=True) or {}
    errors = validate_student_payload(payload)
    if errors:
        return jsonify({"errors": errors}), 400

    if db.student_id_exists(payload["student_id"].strip(), exclude_record_id=record_id):
        return jsonify({"errors": [f"Student ID '{payload['student_id']}' already exists."]}), 409

    features = extract_features(payload)
    try:
        result = ml.predict_student(features)
    except ml.ModelNotTrainedError as e:
        return jsonify({"errors": [str(e)]}), 503

    record = {
        "student_id": payload["student_id"].strip(),
        "name": payload["name"].strip(),
        **features,
        "predicted_score": result["predicted_score"],
        "performance_category": result["performance_category"],
    }

    db.update_student(record_id, record)
    student = db.get_student_by_id(record_id)

    return jsonify(
        {
            "student": student,
            "recommendations": result["recommendations"],
            "model_used": result["model_used"],
        }
    )


@app.route("/api/students/<int:record_id>", methods=["DELETE"])
def delete_student(record_id):
    deleted = db.delete_student(record_id)
    if not deleted:
        return jsonify({"errors": ["Student not found."]}), 404
    return jsonify({"message": "Student deleted successfully."})


# ---------------------------------------------------------------------------
# Prediction only (no persistence) - useful for a "what-if" style form
# ---------------------------------------------------------------------------
@app.route("/api/predict", methods=["POST"])
def predict_only():
    payload = request.get_json(silent=True) or {}

    errors = []
    for field in NUMERIC_FIELDS:
        if field not in payload or payload[field] in (None, ""):
            errors.append(f"'{field}' is required.")
    if errors:
        return jsonify({"errors": errors}), 400

    features = extract_features(
        {**{f: 0 for f in ["student_id", "name"]}, **payload}
    )

    try:
        result = ml.predict_student(features)
    except ml.ModelNotTrainedError as e:
        return jsonify({"errors": [str(e)]}), 503

    return jsonify(result)


# ---------------------------------------------------------------------------
# Dashboard statistics
# ---------------------------------------------------------------------------
@app.route("/api/dashboard/stats", methods=["GET"])
def dashboard_stats():
    students = db.get_all_students()
    total = len(students)

    if total == 0:
        return jsonify(
            {
                "total_students": 0,
                "average_marks": 0,
                "average_attendance": 0,
                "high_performing_count": 0,
                "needs_improvement_count": 0,
                "category_breakdown": {},
            }
        )

    avg_marks = sum(s["predicted_score"] or 0 for s in students) / total
    avg_attendance = sum(s["attendance_percentage"] for s in students) / total
    high_performing = sum(
        1 for s in students if s["performance_category"] in ("Excellent", "Good")
    )
    needs_improvement = sum(
        1 for s in students if s["performance_category"] == "Needs Improvement"
    )

    breakdown = {}
    for s in students:
        cat = s["performance_category"] or "Unclassified"
        breakdown[cat] = breakdown.get(cat, 0) + 1

    return jsonify(
        {
            "total_students": total,
            "average_marks": round(avg_marks, 2),
            "average_attendance": round(avg_attendance, 2),
            "high_performing_count": high_performing,
            "needs_improvement_count": needs_improvement,
            "category_breakdown": breakdown,
        }
    )


# ---------------------------------------------------------------------------
# Analytics data (raw points for scatter/bar charts)
# ---------------------------------------------------------------------------
@app.route("/api/analytics/data", methods=["GET"])
def analytics_data():
    students = db.get_all_students()

    points = [
        {
            "name": s["name"],
            "student_id": s["student_id"],
            "attendance_percentage": s["attendance_percentage"],
            "study_hours": s["study_hours"],
            "assignment_score": s["assignment_score"],
            "internal_exam_score": s["internal_exam_score"],
            "predicted_score": s["predicted_score"],
            "performance_category": s["performance_category"],
        }
        for s in students
    ]

    breakdown = {}
    for s in students:
        cat = s["performance_category"] or "Unclassified"
        breakdown[cat] = breakdown.get(cat, 0) + 1

    return jsonify({"points": points, "category_breakdown": breakdown})


# ---------------------------------------------------------------------------
# Model comparison metrics
# ---------------------------------------------------------------------------
@app.route("/api/model/metrics", methods=["GET"])
def model_metrics():
    try:
        metrics = ml.get_metrics()
    except ml.ModelNotTrainedError as e:
        return jsonify({"errors": [str(e)]}), 503
    return jsonify(metrics)


if __name__ == "__main__":
    db.init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
