import React, { useEffect, useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { StudentAPI } from "../api/api";
import { useToast } from "../components/Toast";
import PerformanceBadge from "../components/PerformanceBadge";
import Loader from "../components/Loader";
import ConfirmDialog from "../components/ConfirmDialog";

const CATEGORIES = ["Excellent", "Good", "Average", "Needs Improvement"];

export default function StudentRecords() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [pendingDelete, setPendingDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const { showToast } = useToast();
  const navigate = useNavigate();

  const fetchStudents = useCallback(() => {
    setLoading(true);
    StudentAPI.list({ search, category })
      .then((data) => {
        setStudents(data.students);
        setError("");
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [search, category]);

  useEffect(() => {
    const handle = setTimeout(fetchStudents, 250); // debounce search
    return () => clearTimeout(handle);
  }, [fetchStudents]);

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await StudentAPI.remove(pendingDelete.id);
      showToast(`${pendingDelete.name} was deleted.`, "success");
      setPendingDelete(null);
      fetchStudents();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Student Records</h1>
          <p className="page-subtitle">Search, filter, and manage all tracked students</p>
        </div>
        <Link to="/add-student" className="btn btn-primary">
          + Add Student
        </Link>
      </div>

      <div className="toolbar card">
        <input
          type="text"
          placeholder="Search by name or student ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="toolbar-search"
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)} className="toolbar-select">
          <option value="">All Categories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <Loader label="Loading student records..." />
      ) : error ? (
        <div className="alert alert-error">{error}</div>
      ) : students.length === 0 ? (
        <div className="empty-state">
          <h3>No students found</h3>
          <p>Try adjusting your search or filters, or add a new student.</p>
        </div>
      ) : (
        <div className="card table-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Student ID</th>
                  <th>Name</th>
                  <th>Attendance</th>
                  <th>Study Hrs</th>
                  <th>Predicted Score</th>
                  <th>Category</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s.id}>
                    <td>{s.student_id}</td>
                    <td>{s.name}</td>
                    <td>{s.attendance_percentage}%</td>
                    <td>{s.study_hours}</td>
                    <td>{s.predicted_score ?? "—"}</td>
                    <td>
                      <PerformanceBadge category={s.performance_category} />
                    </td>
                    <td className="table-actions">
                      <button className="btn-link" onClick={() => navigate(`/students/${s.id}`)}>
                        View
                      </button>
                      <button className="btn-link" onClick={() => navigate(`/students/${s.id}/edit`)}>
                        Edit
                      </button>
                      <button className="btn-link btn-link-danger" onClick={() => setPendingDelete(s)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete student record?"
        message={`This will permanently remove ${pendingDelete?.name || "this student"} (${
          pendingDelete?.student_id || ""
        }) from the tracker.`}
        onConfirm={confirmDelete}
        onCancel={() => setPendingDelete(null)}
        confirmLabel={deleting ? "Deleting..." : "Delete"}
      />
    </div>
  );
}
