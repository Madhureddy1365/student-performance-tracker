import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import StatCard from "../components/StatCard";
import Loader from "../components/Loader";
import { DashboardAPI, AnalyticsAPI } from "../api/api";

const CATEGORY_COLORS = {
  Excellent: "#1f9d55",
  Good: "#2f80ed",
  Average: "#e0a02c",
  "Needs Improvement": "#d64545",
  Unclassified: "#94a3b8",
};

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    Promise.all([DashboardAPI.stats(), AnalyticsAPI.data()])
      .then(([statsRes, analyticsRes]) => {
        if (!mounted) return;
        setStats(statsRes);
        setAnalytics(analyticsRes);
        setError("");
      })
      .catch((err) => mounted && setError(err.message))
      .finally(() => mounted && setLoading(false));
    return () => {
      mounted = false;
    };
  }, []);

  if (loading) return <Loader label="Loading dashboard..." />;

  if (error) {
    return (
      <div className="page">
        <div className="alert alert-error">{error}</div>
      </div>
    );
  }

  const pieData = Object.entries(stats.category_breakdown || {}).map(([name, value]) => ({
    name,
    value,
  }));

  const barData = Object.entries(stats.category_breakdown || {}).map(([name, value]) => ({
    name,
    students: value,
  }));

  const isEmpty = stats.total_students === 0;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p className="page-subtitle">Overview of student academic performance</p>
        </div>
        <Link to="/add-student" className="btn btn-primary">
          + Add Student
        </Link>
      </div>

      <div className="stat-grid">
        <StatCard label="Total Students" value={stats.total_students} tone="default" />
        <StatCard label="Average Predicted Score" value={stats.average_marks} suffix="/100" tone="info" />
        <StatCard label="Average Attendance" value={stats.average_attendance} suffix="%" tone="info" />
        <StatCard label="High Performing" value={stats.high_performing_count} tone="good" />
        <StatCard label="Needs Improvement" value={stats.needs_improvement_count} tone="poor" />
      </div>

      {isEmpty ? (
        <div className="empty-state">
          <h3>No students yet</h3>
          <p>Add your first student to see performance statistics and charts here.</p>
          <Link to="/add-student" className="btn btn-primary">
            Add a Student
          </Link>
        </div>
      ) : (
        <div className="chart-grid">
          <div className="card chart-card">
            <h3>Performance Distribution</h3>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={95}
                  label={(entry) => `${entry.name}: ${entry.value}`}
                >
                  {pieData.map((entry) => (
                    <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] || "#94a3b8"} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="card chart-card">
            <h3>Students per Category</h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e9f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="students" radius={[6, 6, 0, 0]}>
                  {barData.map((entry) => (
                    <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] || "#94a3b8"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
