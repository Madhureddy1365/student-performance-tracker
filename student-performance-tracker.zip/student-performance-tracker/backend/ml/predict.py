"""
predict.py
----------
Loads the trained model/scaler produced by train_model.py and exposes a
single `predict_student(features: dict)` function used by the Flask API.
"""

import os
import json
import joblib
import numpy as np

MODEL_DIR = os.path.dirname(os.path.abspath(__file__)) + "/models"

_model = None
_scaler = None
_feature_columns = None
_metrics = None


class ModelNotTrainedError(Exception):
    pass


def _load_artifacts():
    global _model, _scaler, _feature_columns, _metrics

    model_path = os.path.join(MODEL_DIR, "best_model.pkl")
    scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
    metrics_path = os.path.join(MODEL_DIR, "metrics.json")

    if not (os.path.exists(model_path) and os.path.exists(scaler_path)):
        raise ModelNotTrainedError(
            "No trained model found. Run `python ml/train_model.py` from the "
            "backend/ directory first."
        )

    _model = joblib.load(model_path)
    _scaler = joblib.load(scaler_path)

    with open(metrics_path) as f:
        _metrics = json.load(f)
    _feature_columns = _metrics["feature_columns"]


def get_metrics() -> dict:
    if _metrics is None:
        _load_artifacts()
    return _metrics


def classify(score: float) -> str:
    if score >= 85:
        return "Excellent"
    if score >= 70:
        return "Good"
    if score >= 50:
        return "Average"
    return "Needs Improvement"


def build_recommendations(features: dict, category: str) -> list:
    tips = []

    if features["attendance_percentage"] < 75:
        tips.append("Improve attendance — aim for at least 75% to stay on track.")
    if features["study_hours"] < 3:
        tips.append("Increase daily study hours; try adding at least 1-2 focused hours.")
    if features["assignment_score"] < 60:
        tips.append("Revisit assignment fundamentals — scores suggest gaps in core concepts.")
    if features["assignments_completed"] < 12:
        tips.append("Complete pending assignments — missing submissions are dragging down performance.")
    if features["internal_exam_score"] < 60:
        tips.append("Focus on internal exam preparation with regular revision sessions.")
    if features["participation_score"] < 5:
        tips.append("Participate more actively in class discussions and activities.")
    if features["previous_marks"] < 60:
        tips.append("Strengthen fundamentals from previous semester topics before moving ahead.")

    if not tips:
        if category == "Excellent":
            tips.append("Great work — maintain this consistency and consider mentoring peers.")
        else:
            tips.append("Keep up the steady effort across all areas.")

    return tips


def predict_student(features: dict) -> dict:
    """
    features: dict with keys matching FEATURE_COLUMNS in train_model.py:
        attendance_percentage, study_hours, previous_marks, assignment_score,
        internal_exam_score, assignments_completed, participation_score
    """
    if _model is None:
        _load_artifacts()

    ordered_values = [[features[col] for col in _feature_columns]]
    X = np.array(ordered_values, dtype=float)
    X_scaled = _scaler.transform(X)

    raw_pred = float(_model.predict(X_scaled)[0])
    predicted_score = float(np.clip(raw_pred, 0, 100))
    category = classify(predicted_score)
    recommendations = build_recommendations(features, category)

    return {
        "predicted_score": round(predicted_score, 2),
        "performance_category": category,
        "recommendations": recommendations,
        "model_used": _metrics["best_model"],
    }
