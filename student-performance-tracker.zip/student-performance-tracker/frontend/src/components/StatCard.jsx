import React from "react";

export default function StatCard({ label, value, tone = "default", suffix = "" }) {
  return (
    <div className={`stat-card stat-card-${tone}`}>
      <div className="stat-card-label">{label}</div>
      <div className="stat-card-value">
        {value}
        {suffix && <span className="stat-card-suffix">{suffix}</span>}
      </div>
    </div>
  );
}
