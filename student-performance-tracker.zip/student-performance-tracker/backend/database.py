"""
database.py
------------
SQLite database setup and access helpers for the Student Performance Tracker.

Uses plain sqlite3 (no ORM) so the project has zero extra dependencies
beyond what's already in requirements.txt.
"""

import sqlite3
import os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "student_tracker.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    attendance_percentage REAL NOT NULL,
    study_hours REAL NOT NULL,
    previous_marks REAL NOT NULL,
    assignment_score REAL NOT NULL,
    internal_exam_score REAL NOT NULL,
    assignments_completed INTEGER NOT NULL,
    participation_score REAL NOT NULL,
    predicted_score REAL,
    performance_category TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create the students table if it doesn't already exist."""
    conn = get_connection()
    try:
        conn.execute(SCHEMA)
        conn.commit()
    finally:
        conn.close()


def row_to_dict(row: sqlite3.Row) -> dict:
    return {key: row[key] for key in row.keys()}


def insert_student(data: dict) -> int:
    conn = get_connection()
    now = datetime.utcnow().isoformat()
    try:
        cur = conn.execute(
            """
            INSERT INTO students (
                student_id, name, attendance_percentage, study_hours,
                previous_marks, assignment_score, internal_exam_score,
                assignments_completed, participation_score,
                predicted_score, performance_category, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["student_id"],
                data["name"],
                data["attendance_percentage"],
                data["study_hours"],
                data["previous_marks"],
                data["assignment_score"],
                data["internal_exam_score"],
                data["assignments_completed"],
                data["participation_score"],
                data.get("predicted_score"),
                data.get("performance_category"),
                now,
                now,
            ),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_all_students() -> list:
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM students ORDER BY created_at DESC").fetchall()
        return [row_to_dict(r) for r in rows]
    finally:
        conn.close()


def get_student_by_id(record_id: int):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM students WHERE id = ?", (record_id,)).fetchone()
        return row_to_dict(row) if row else None
    finally:
        conn.close()


def student_id_exists(student_id: str, exclude_record_id: int = None) -> bool:
    conn = get_connection()
    try:
        if exclude_record_id:
            row = conn.execute(
                "SELECT id FROM students WHERE student_id = ? AND id != ?",
                (student_id, exclude_record_id),
            ).fetchone()
        else:
            row = conn.execute(
                "SELECT id FROM students WHERE student_id = ?", (student_id,)
            ).fetchone()
        return row is not None
    finally:
        conn.close()


def update_student(record_id: int, data: dict) -> bool:
    conn = get_connection()
    now = datetime.utcnow().isoformat()
    try:
        cur = conn.execute(
            """
            UPDATE students SET
                student_id = ?, name = ?, attendance_percentage = ?,
                study_hours = ?, previous_marks = ?, assignment_score = ?,
                internal_exam_score = ?, assignments_completed = ?,
                participation_score = ?, predicted_score = ?,
                performance_category = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                data["student_id"],
                data["name"],
                data["attendance_percentage"],
                data["study_hours"],
                data["previous_marks"],
                data["assignment_score"],
                data["internal_exam_score"],
                data["assignments_completed"],
                data["participation_score"],
                data.get("predicted_score"),
                data.get("performance_category"),
                now,
                record_id,
            ),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def delete_student(record_id: int) -> bool:
    conn = get_connection()
    try:
        cur = conn.execute("DELETE FROM students WHERE id = ?", (record_id,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()
