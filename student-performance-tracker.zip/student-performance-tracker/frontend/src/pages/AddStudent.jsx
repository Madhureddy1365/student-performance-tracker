import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { StudentAPI } from "../api/api";
import { useToast } from "../components/Toast";
import PerformanceBadge from "../components/PerformanceBadge";
import Loader from "../components/Loader";

const EMPTY_FORM = {
  student_id: "",
  name: "",
  attendance_percentage: "",
  study_hours: "",
  previous_marks: "",
  assignment_score: "",
  internal_exam_score: "",
  assignments_completed: "",
  participation_score: "",
};

const FIELD_META = [
  { key: "student_id", label: "Student ID", type: "text", placeholder: "e.g. STU1042" },
  { key: "name", label: "Student Name", type: "text", placeholder: "e.g. Priya Sharma" },
  { key: "attendance_percentage", label: "Attendance Percentage", type: "number", min: 0, max: 100, step: 0.1, hint: "0–100%" },
  { key: "study_hours", label: "Study Hours (daily avg.)", type: "number", min: 0, max: 24, step: 0.1, hint: "hours/day" },
  { key: "previous_marks", label: "Previous Semester Marks", type: "number", min: 0, max: 100, step: 0.1, hint: "0–100" },
  { key: "assignment_score", label: "Assignment Score", type: "number", min: 0, max: 100, step: 0.1, hint: "0–100" },
  { key: "internal_exam_score", label: "Internal Exam Score", type: "number", min: 0, max: 100, step: 0.1, hint: "0–100" },
  { key: "assignments_completed", label: "Assignments Completed", type: "number", min: 0, max: 100, step: 1, hint: "count" },
  { key: "participation_score", label: "Participation Score", type: "number", min: 0, max: 10, step: 0.1, hint: "0–10" },
];

export default function AddStudent() {
  const { id } = useParams();
  const isEditMode = Boolean(id);
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [form, setForm] = useState(EMPTY_FORM);
  const [fieldErrors, setFieldErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [loadingRecord, setLoadingRecord] = useState(isEditMode);
  const [result, setResult] = useState(null);
  const [formError, setFormError] = useState("");

  useEffect(() => {
    if (!isEditMode) return;
    let mounted = true;
    StudentAPI.get(id)
      .then((data) => {
        if (!mounted) return;
        const s = data.student;
        setForm({
          student_id: s.student_id,
          name: s.name,
          attendance_percentage: s.attendance_percentage,
          study_hours: s.study_hours,
          previous_marks: s.previous_marks,
          assignment_score: s.assignment_score,
          internal_exam_score: s.internal_exam_score,
          assignments_completed: s.assignments_completed,
          participation_score: s.participation_score,
        });
      })
      .catch((err) => mounted && setFormError(err.message))
      .finally(() => mounted && setLoadingRecord(false));
    return () => {
      mounted = false;
    };
  }, [id, isEditMode]);

  function handleChange(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setFieldErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  function validate() {
    const errors = {};
    FIELD_META.forEach((field) => {
      const value = form[field.key];
      if (value === "" || value === null || value === undefined) {
        errors[field.key] = "Required";
        return;
      }
      if (field.type === "number") {
        const num = Number(value);
        if (Number.isNaN(num)) {
          errors[field.key] = "Must be a number";
        } else if (field.min !== undefined && num < field.min) {
          errors[field.key] = `Must be at least ${field.min}`;
        } else if (field.max !== undefined && num > field.max) {
          errors[field.key] = `Must be at most ${field.max}`;
        }
      }
    });
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setFormError("");
    setResult(null);

    if (!validate()) return;

    const payload = {
      ...form,
      attendance_percentage: Number(form.attendance_percentage),
      study_hours: Number(form.study_hours),
      previous_marks: Number(form.previous_marks),
      assignment_score: Number(form.assignment_score),
      internal_exam_score: Number(form.internal_exam_score),
      assignments_completed: Number(form.assignments_completed),
      participation_score: Number(form.participation_score),
    };

    setSubmitting(true);
    try {
      const data = isEditMode
        ? await StudentAPI.update(id, payload)
        : await StudentAPI.create(payload);

      setResult(data);
      showToast(
        isEditMode ? "Student updated successfully." : "Student added and prediction generated.",
        "success"
      );

      if (!isEditMode) {
        setForm(EMPTY_FORM);
      }
    } catch (err) {
      setFormError(err.message);
      showToast(err.message, "error");
    } finally {
      setSubmitting(false);
    }
  }

  if (loadingRecord) return <Loader label="Loading student record..." />;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>{isEditMode ? "Edit Student" : "Add Student"}</h1>
          <p className="page-subtitle">
            {isEditMode
              ? "Update academic details — the performance prediction will be recalculated."
              : "Enter academic and attendance details to generate an ML-based performance prediction."}
          </p>
        </div>
      </div>

      <div className="form-layout">
        <form className="card form-card" onSubmit={handleSubmit} noValidate>
          {formError && <div className="alert alert-error">{formError}</div>}

          <div className="form-grid">
            {FIELD_META.map((field) => (
              <div className="form-field" key={field.key}>
                <label htmlFor={field.key}>
                  {field.label} {field.hint && <span className="field-hint">({field.hint})</span>}
                </label>
                <input
                  id={field.key}
                  type={field.type}
                  min={field.min}
                  max={field.max}
                  step={field.step}
                  placeholder={field.placeholder}
                  value={form[field.key]}
                  onChange={(e) => handleChange(field.key, e.target.value)}
                  className={fieldErrors[field.key] ? "input-error" : ""}
                  disabled={field.key === "student_id" && isEditMode}
                />
                {fieldErrors[field.key] && (
                  <span className="field-error">{fieldErrors[field.key]}</span>
                )}
              </div>
            ))}
          </div>

          <div className="form-actions">
            <button type="button" className="btn btn-ghost" onClick={() => navigate(-1)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? "Saving..." : isEditMode ? "Update Student" : "Add Student & Predict"}
            </button>
          </div>
        </form>

        <div className="prediction-panel">
          {result ? (
            <div className="card prediction-card">
              <h3>Predicted Performance</h3>
              <div className="prediction-score">{result.student.predicted_score}</div>
              <div className="prediction-score-label">out of 100</div>
              <PerformanceBadge category={result.student.performance_category} />

              <div className="prediction-meta">
                Model used: <strong>{result.model_used}</strong>
              </div>

              <h4>Recommendations</h4>
              <ul className="recommendation-list">
                {result.recommendations.map((tip, idx) => (
                  <li key={idx}>{tip}</li>
                ))}
              </ul>

              <button className="btn btn-secondary" onClick={() => navigate("/students")}>
                View All Students
              </button>
            </div>
          ) : (
            <div className="card prediction-card prediction-placeholder">
              <h3>Prediction Preview</h3>
              <p>
                Submit the form to see the ML-predicted final score, performance category, and
                personalized recommendations here.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
