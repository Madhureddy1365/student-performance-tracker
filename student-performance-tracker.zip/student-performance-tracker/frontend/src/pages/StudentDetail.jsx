import React, { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { StudentAPI } from "../api/api";
import { useToast } from "../components/Toast";
import PerformanceBadge from "../components/PerformanceBadge";
import Loader from "../components/Loader";
import ConfirmDialog from "../components/ConfirmDialog";

const DETAIL_FIELDS = [
  { key: "attendance_percentage", label: "Attendance", suffix: "%" },
  { key: "study_hours", label: "Study Hours / day", suffix: "" },
  { key: "previous_marks", label: "Previous Semester Marks", suffix: "" },
  { key: "assignment_score", label: "Assignment Score", suffix: "" },
  { key: "internal_exam_score", label: "Internal Exam Score", suffix: "" },
  { key: "assignments_completed", label: "Assignments Completed", suffix: "" },
  { key: "participation_score", label: "Participation Score", suffix: "/10" },
];

export default function StudentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    let mounted = true;
    StudentAPI.get(id)
      .then((res) => mounted && setData(res))
      .catch((err) => mounted && setError(err.message))
      .finally(() => mounted && setLoading(false));
    return () => {
      mounted = false;
    };
  }, [id]);

  async function handleDelete() {
    setDeleting(true);
    try {
      await StudentAPI.remove(id);
      showToast("Student deleted successfully.", "success");
      navigate("/students");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setDeleting(false);
      setConfirmOpen(false);
    }
  }

  if (loading) return <Loader label="Loading student details..." />;
  if (error) {
    return (
      <div className="page">
        <div className="alert alert-error">{error}</div>
        <Link to="/students" className="btn btn-ghost" style={{ marginTop: 16 }}>
          Back to Records
        </Link>
      </div>
    );
  }

  const { student, recommendations } = data;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>{student.name}</h1>
          <p className="page-subtitle">{student.student_id}</p>
        </div>
        <div className="page-header-actions">
          <button className="btn btn-ghost" onClick={() => navigate(`/students/${id}/edit`)}>
            Edit
          </button>
          <button className="btn btn-danger" onClick={() => setConfirmOpen(true)}>
            Delete
          </button>
        </div>
      </div>

      <div className="detail-layout">
        <div className="card">
          <h3>Academic Details</h3>
          <dl className="detail-list">
            {DETAIL_FIELDS.map((f) => (
              <div className="detail-row" key={f.key}>
                <dt>{f.label}</dt>
                <dd>
                  {student[f.key]}
                  {f.suffix}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="card prediction-card">
          <h3>Predicted Performance</h3>
          <div className="prediction-score">{student.predicted_score ?? "—"}</div>
          <div className="prediction-score-label">out of 100</div>
          <PerformanceBadge category={student.performance_category} />

          <h4>Recommendations</h4>
          {recommendations && recommendations.length > 0 ? (
            <ul className="recommendation-list">
              {recommendations.map((tip, idx) => (
                <li key={idx}>{tip}</li>
              ))}
            </ul>
          ) : (
            <p className="page-subtitle">No recommendations available.</p>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={confirmOpen}
        title="Delete student record?"
        message={`This will permanently remove ${student.name} (${student.student_id}) from the tracker.`}
        onConfirm={handleDelete}
        onCancel={() => setConfirmOpen(false)}
        confirmLabel={deleting ? "Deleting..." : "Delete"}
      />
    </div>
  );
}
