import axios from "axios";

// In development, CRA's "proxy" field in package.json forwards /api to
// http://localhost:5000. In production, set REACT_APP_API_BASE_URL to the
// deployed backend URL at build time.
const BASE_URL = process.env.REACT_APP_API_BASE_URL || "";

const client = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 15000,
});

// Normalises errors so callers can always read `error.message` and
// optionally `error.details` (array of field-level messages from Flask).
client.interceptors.response.use(
  (response) => response,
  (error) => {
    const data = error.response?.data;
    const message =
      (data && data.errors && data.errors.join(" ")) ||
      error.message ||
      "Something went wrong. Please try again.";
    return Promise.reject({ message, details: data?.errors || [], status: error.response?.status });
  }
);

export const StudentAPI = {
  list: (params = {}) => client.get("/api/students", { params }).then((r) => r.data),
  get: (id) => client.get(`/api/students/${id}`).then((r) => r.data),
  create: (payload) => client.post("/api/students", payload).then((r) => r.data),
  update: (id, payload) => client.put(`/api/students/${id}`, payload).then((r) => r.data),
  remove: (id) => client.delete(`/api/students/${id}`).then((r) => r.data),
  predict: (payload) => client.post("/api/predict", payload).then((r) => r.data),
};

export const DashboardAPI = {
  stats: () => client.get("/api/dashboard/stats").then((r) => r.data),
};

export const AnalyticsAPI = {
  data: () => client.get("/api/analytics/data").then((r) => r.data),
};

export const ModelAPI = {
  metrics: () => client.get("/api/model/metrics").then((r) => r.data),
};

export default client;
